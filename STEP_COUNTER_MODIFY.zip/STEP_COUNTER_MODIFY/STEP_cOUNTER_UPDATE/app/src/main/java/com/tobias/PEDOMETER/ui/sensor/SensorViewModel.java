package com.tobias.PEDOMETER.ui.sensor;

import androidx.lifecycle.ViewModel;

public class SensorViewModel extends ViewModel {

}
