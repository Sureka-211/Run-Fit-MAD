package com.tobias.PEDOMETER;

/**
        * The StepType enum contains the possible step types.
        */
public enum StepType {
    WALKING,
    JOGGING,
    RUNNING
}
